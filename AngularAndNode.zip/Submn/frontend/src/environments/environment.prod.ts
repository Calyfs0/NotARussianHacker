export const environment = {
  production: true,
  authUrl: '/api/',
  serverUrl: '/api/',
};
