export enum Mode {
  Create,
  Edit,
  Display,
}
