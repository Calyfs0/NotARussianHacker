export interface Option {
  id: number;
  text: string;
}
