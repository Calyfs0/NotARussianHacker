export enum selectedOption {
  First,
  Second,
  Third,
  Fourth,
}
