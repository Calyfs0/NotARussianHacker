export interface Question {
  question: string;
  category: string;
}
