﻿using MvcApplication2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MvcApplication2.Controllers
{
    public class UserDashboardController : ApiController
    {
        [HttpPost]
        public List<UserMarks> GetUserMarks(List<TestInput> input)
        {
            List<UserMarks> UserMarks = new List<UserMarks>();

            using (idkEntities idkEntities = new idkEntities())
            {

                foreach (TestInput t in input)
                {
                    int marks = 0;
                    bool isCorrect = idkEntities.IdkOptions.FirstOrDefault(i => i.OptionsId == t.optionid && i.QuestionId == t.questionid).IsCorrect;
                    int levelid = idkEntities.IdkQuestions.FirstOrDefault(i => i.QuestionId == t.questionid).LevelId;
                    int categoryid = idkEntities.IdkQuestions.FirstOrDefault(i => i.QuestionId == t.questionid).CategoryId;
                    if (isCorrect)
                    {
                        marks = idkEntities.IdkLevels.FirstOrDefault(i => i.LevelId == levelid).LevelMarks;
                    }

                    UserMarks m = new UserMarks();
                    m.categoryid = categoryid;
                    m.categoryname = idkEntities.IdkCategories.FirstOrDefault(i => i.CategoryId == categoryid).CategoryName;
                    m.marks = marks;
                    m.totalmarks = 100;

                    UserMarks.Add(m);
                }
            }
            return UserMarks;

        }

        [HttpPost]
        public List<Recommendations> GetRecommendedPathForBasicTest(List<TotalMarks> input)
        {

            int programmingMarks = 0;
            int designingMarks = 0;
            int networkingMarks = 0;
            int mathematicsMarks = 0;
            int total = 0;
            foreach (TotalMarks t in input)
            {
                switch (t.categoryid)
                {
                    case 1:
                        programmingMarks = t.totalmarks;
                        total += programmingMarks;
                        break;
                    case 2:
                        mathematicsMarks = t.totalmarks;
                        total += mathematicsMarks;
                        break;
                    case 3:
                        designingMarks = t.totalmarks;
                        total += designingMarks;
                        break;
                    case 4:
                        networkingMarks = t.totalmarks;
                        total += networkingMarks;
                        break;
                    default:
                        break;
                }
            }

            List<Recommendations> output = new List<Recommendations>();
            using (idkEntities idkEntities = new idkEntities())
            {
                if (programmingMarks >= 70 && mathematicsMarks >= 70 && networkingMarks < 60 && designingMarks < 60)
                {
                    
                    output = idkEntities.IdkRecommendedPaths.Where(i=> i.PathId == 1 || i.PathId == 3 || i.PathId == 8).Select(x=> new Recommendations{ pathid = x.PathId, path = x.PathValue}).ToList();
                   
                }
                else if (networkingMarks >= 70 && programmingMarks < 60 && mathematicsMarks < 60 && designingMarks < 60)
                {
                    output = idkEntities.IdkRecommendedPaths.Where(i=> i.PathId == 7).Select(x=> new Recommendations{ pathid = x.PathId, path = x.PathValue}).ToList();
                    
                }
                else if (designingMarks >= 70 && networkingMarks < 60 && programmingMarks < 60 && mathematicsMarks < 60)
                {
                    output = idkEntities.IdkRecommendedPaths.Where(i=> i.PathId == 2).Select(x=> new Recommendations{ pathid = x.PathId, path = x.PathValue}).ToList();
                    
                }
                else if (total > 250)
                {
                    output = idkEntities.IdkRecommendedPaths.Where(i => i.PathId == 1 || i.PathId == 2 || i.PathId == 3 || i.PathId == 4 || i.PathId == 5 || i.PathId == 6 || i.PathId == 7 || i.PathId == 8).Select(x => new Recommendations { pathid = x.PathId, path = x.PathValue }).ToList();
                }
                else
                {
                    return null;
                }
            }

            return output;
            

        }
    }
}