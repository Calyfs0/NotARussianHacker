﻿using MvcApplication2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MvcApplication2.Controllers
{
    public class TestController : ApiController
    {
        [HttpPost]
        public List<TestQuestionsAndOptions> GetQuestionsAndOptions() {

            List<TestQuestionsAndOptions> QuestionsList = new List<TestQuestionsAndOptions>();
            using (idkEntities idkEntities = new idkEntities())
            {

                List<IdkQuestion> QuestionList = idkEntities.IdkQuestions.Where(i => i.CategoryId == 1 || i.CategoryId == 2 || i.CategoryId == 3 || i.CategoryId == 4).ToList();

                foreach (IdkQuestion Q in QuestionList) {
                    String category = idkEntities.IdkCategories.FirstOrDefault(i=> i.CategoryId == Q.CategoryId).CategoryName;
                    int marks = idkEntities.IdkLevels.FirstOrDefault(i => i.LevelId == Q.LevelId).LevelMarks;
                    String question = Q.QuestionText;
                    List<Options> OptionsList = idkEntities.IdkOptions.Where(i => i.QuestionId == Q.QuestionId).Select(x => new Options { id = x.OptionsId, text = x.OptionsText }).ToList();

                    

                    TestQuestionsAndOptions quest = new TestQuestionsAndOptions();
                    quest.category = category;
                    quest.id = Q.QuestionId;
                    quest.options = OptionsList;
                    quest.marks = marks;
                    quest.question = question;

                    QuestionsList.Add(quest);
                }

            }
            
            return QuestionsList;
        }

       
    }
}