﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class Recommendations
    {
        public int pathid { get; set; }
        public string path { get; set; }
    }
}