﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class UserMarks
    {
        public int categoryid { get; set; }
        public string categoryname { get; set; }
        public int marks { get; set; }
        public int totalmarks { get; set; }
    }
}