﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class TotalMarks
    {
        public int categoryid { get; set; }
        public int totalmarks { get; set; }
    }
}