﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class TestQuestionsAndOptions
    {
        public int id { get; set; }
        public string question { get; set; }
        public List<Options> options { get; set; }
        public string category { get; set; }
        public int marks { get; set; }
    }
}